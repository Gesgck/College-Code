package ast.expression;

/**
 * Represents any literal value in the language.
 */
public abstract class Literal extends Expression {
}
